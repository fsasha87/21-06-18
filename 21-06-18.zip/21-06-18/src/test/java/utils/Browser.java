package utils;

public enum Browser {
    CHROME,
    IE
}
